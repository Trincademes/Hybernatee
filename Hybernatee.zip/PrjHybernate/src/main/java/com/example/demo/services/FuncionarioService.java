package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Funcionario;
import com.example.demo.repositories.FuncionarioRepository;

@Service
public class FuncionarioService {

    @Autowired
    private FuncionarioRepository funcionarioRepository;

    public FuncionarioService (FuncionarioRepository funcionarioRepository) {
        this.funcionarioRepository = funcionarioRepository;
    }

    
    public Funcionario findFuncionarioById(Long id) {
        Optional<Funcionario> Funcionario = funcionarioRepository.findById(id);
        return Funcionario.orElse(null);
    }

   
    public List<Funcionario> findAllFuncionario() {
        return funcionarioRepository.findAll();
    }

    
    public Funcionario insertFuncionarioo(Funcionario funcionario) {
        return funcionarioRepository.save(funcionario);
    }


	public List<Funcionario> getAllFuncionario() {
		// TODO Auto-generated method stub
		return null;
	}


	public void deleteFuncionario(Long id) {
		// TODO Auto-generated method stub
		
	}


	public Funcionario saveFuncionario(Funcionario funcionario) {
		// TODO Auto-generated method stub
		return null;
	}

    
}
